<?php 
	header('Location: nfl_prop.php'); 
	die();
?>



